<?php
// LAB SHEET 9 - QUESTION 6: Secure logout
session_start();

$_SESSION = array();
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), "", time() - 3600, $params["path"],
        $params["domain"], $params["secure"], $params["httponly"]);
}
session_destroy();

header("Location: 4.php");
exit;
?>
